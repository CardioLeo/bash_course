package main

import (
	"fmt"
)

func main() {
	// x := "Hello, World"
	x := 5
	fmt.Println(x)
	dogsName := "Max"
	fmt.Println("My dog's name is", dogsName)
}
