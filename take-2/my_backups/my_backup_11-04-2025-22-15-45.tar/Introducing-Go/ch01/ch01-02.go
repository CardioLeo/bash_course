package main

import "fmt"

// this is a comment, of course, but this comment is in the book

func main() {
	name := "William"
	fmt.Println("Hello, my name is", name)
}
