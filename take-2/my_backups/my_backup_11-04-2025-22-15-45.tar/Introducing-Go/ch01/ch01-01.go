package main

import "fmt"

// this is a comment, of course, but this comment is in the book

func main() {
	fmt.Println("Hello, World")
}
