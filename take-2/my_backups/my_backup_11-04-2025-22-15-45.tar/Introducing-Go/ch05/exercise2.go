package main

import (
	"fmt"
)

func main() {
	x := make([]int, 3, 9)
	fmt.Println(len(x))
}
