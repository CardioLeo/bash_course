package main

import (
	"fmt"
)

func main() {
	fmt.Println("XX 01 XX finish exercise 04, in ch08 ---- done")
	fmt.Println("-- 02 -- look for code from MostNotable from chapters 7, 8, 9, & 10 to add to the MostNotable folder")
	fmt.Println("XX 03 XX finish typing up and running all code in the book, so I can move onto Kernighan and Pike ---- done")
	fmt.Println("-- 04 -- consider figuring out how to make more code from chapter 8 work - specifically the web and cli stuff")
	fmt.Println("-- 05 -- look over the exercises for chapter 9 & 10 - maybe do one or two")
}
