package main

import (
	"fmt"
	"os"
)

func main() {
	var s, sep string
	for i := 1; i < len(os.Args); i++ {
		s += sep + os.Args[i]
		sep = " as "
	}
	fmt. Println(s)
}

// example
// go run 01-01.go 1 2 3 4 5
// returns:
// "1 as 2 as 3 as 4 as 5"
