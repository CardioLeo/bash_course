package main

import (
	"fmt"
	"os"
	"strings"
)

func main() {
	fmt.Println(strings.Join(os.Args[1:], " "))
}

// running:
// go run 03-01.go I am saying this
// returns:
// I am saying this
