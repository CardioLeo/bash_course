package main

import (
	"fmt"
	"os"
)

func main() {

	s, sep := "", ", now what? "
	for _, arg := range os.Args[1:] {
		s += arg + sep // order of operands is reversed in book
		// sep = " " // this isn't commented out in book
	}
	fmt.Println(s)
}
