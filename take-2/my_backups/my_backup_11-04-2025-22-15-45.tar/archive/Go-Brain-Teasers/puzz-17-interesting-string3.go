package main

import (
	"fmt"
)

func main() {
	data := []byte{'1', '2', '9'}
	s := string(data)
	fmt.Println(s) // 129, the book says the output will be
}
