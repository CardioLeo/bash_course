package main

import (
	"fmt"
	"sync"
	"time"
)

func main() {
	var wg sync.WaitGroup
	for _, n := range []int{3, 1, 2} {
		wg.Add(1)
		go func() {
			defer wg.Done()
			time.Sleep(time.Duration(n) * time.Millisecond)
			fmt.Printf("%d ", n)
		} ()
	}
	wg.Wait()
	fmt.Println()
}

// output due to typo:
// # command-line-arguments
// ./puzz-8-sleep-sort.go:15:39: undefined: time.Milisecond

// output after fixing typo:
// 2 2 2
// and yeah, this is what the next page suggests you'll get

// there are two options for solving this bug, book says
// these two options will by typed up as second and third versions
// of this puzzle
