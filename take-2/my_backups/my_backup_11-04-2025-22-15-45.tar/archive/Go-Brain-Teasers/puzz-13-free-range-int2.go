package main

import (
	"fmt"
)

func fibs(n int) chan int {
	ch := make(chan int)

	go func() {
		defer close(ch) // <1>
		a, b := 1, 1
		for i := 0; i < n; i++ {
			ch <- a
			a, b = b, a+b
		}
	}()

	return ch
}

func main() {
	for i := range fibs(13) {
		fmt.Printf("%d ", i)
	}
	fmt.Println()
}

// this works, its great: 1 1 2 3 5 8 13 21 34 55 89 144 233
