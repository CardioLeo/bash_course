package main

import (
	"fmt"
)

func main() {
	ch := make(chan int, 1)
	ch <- 1
	a, ok := <-ch
	fmt.Println(a, ok) // 1 true
	close(ch)
	b, ok := <-ch
	fmt.Println(b, ok) // 0 false
}

// this actually dead-locked initially because I forgot line 2 of main()
// here is line 2:         ch <- 1

// it gave similar errors as I recorded in puzz-16-*2.go

// now that the missing line is added, it gave the expected output

// 1 true
// 0 false
