package main
import (
	"fmt"
)

func main() {
	var pi = 22 / 7.0
	fmt.Println(pi)
}

// this didn't print exactly what the brain teasers book gave us
// it gave: 3.142857142857143
// which difers after the first 4
