package main

import (
	"fmt"
)

func main() {
	r1 := '™'
	fmt.Println(r1) 	// 8482 // but it won't do this because I didn't use the special character
	fmt.Printf("%c\n", r1) // "™" special character

	r2 := '\x61' 		// \x -2 digits
	fmt.Printf("%c\n", r2) 	// a

	r3 := '\u2122'		// \u -4 digits (8482 in hex)
	fmt.Printf("%c\n", r3) 	// "tm" special character

	r4 := '\U00002122'	// \U - 8 digits
	fmt.Printf("%c\n", r4)	// "tm special character"

				// wow, that's a lot of ways to use the tm character
}

// updated this with the output so that now it actually uses the special tm character: ™
