package main

import (
	"fmt"
)

func main() {
	city1, city2 := "Krakow", "Krakow"
		// special character used, but not here...
	fmt.Println(city1 == city2)
}

// this probably won't work... it even has a warning about not copying
// from the pdf but only from their source code file, which I may try
// in a bit.

// results in true, but again, that's without their version of the code
// nor any special characters
