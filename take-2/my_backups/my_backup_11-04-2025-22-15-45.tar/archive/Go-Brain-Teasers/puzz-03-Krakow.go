package main

import (
	"fmt"
)

func main() {
	city := "Krakow"
	// ha, I don't have easy the special character
	//which the puzzle requires... and I'm offline
	fmt.Println(len(city))
}

// But this does present what I had thought it would - before
// I read the rest of the puzzle
