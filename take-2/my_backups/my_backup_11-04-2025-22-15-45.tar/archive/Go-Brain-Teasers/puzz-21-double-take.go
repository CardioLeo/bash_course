package main

import (
	"fmt"
)

func init() {
	fmt.Printf("A ")
}

func init() {
	fmt.Printf("B ")
}

		// note: the A and B look italized in the book

func main() {
	fmt.Println()
}

// code prints "A B " as expected from reading the book previously
// 
// I want to test this without the command in main
