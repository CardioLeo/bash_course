package main

import (
	"fmt"
)

func fibs(n int) chan int {
	ch := make(chan int)

	go func() {
		defer close(ch)
		a, b := 1, 1
		for i := 0; i < n; i++ {
			a, b = b, a+b
		}
	}()

	return ch
}

func main() {
	ch := fibs(5)
	for {
		i, ok := <-ch
		if !ok {
			break
		}
		fmt.Printf("%d ", i)
	}
	fmt.Println()
}

// I ran this 3 times and it had no output....
// is that to illustrate what it says next?
// "You need to beware of go routine leaks"?

// I'll put the next solution in another document
