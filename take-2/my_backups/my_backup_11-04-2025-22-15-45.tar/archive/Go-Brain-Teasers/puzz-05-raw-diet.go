package main

import (
	"fmt"
)

func main() {
	s := `a/tb`
	fmt.Println(s)
}

// prints out quite literally, "a/tb"

// the backtics area way to make or denote "raw strings," or
// "multiline strings." See puzzle 5, verson 2
