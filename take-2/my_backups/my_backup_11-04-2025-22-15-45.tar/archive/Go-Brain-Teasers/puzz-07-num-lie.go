package main

import (
	"fmt"
	"math"
)

func main() {
	n := 1.1
	fmt.Println(n * n)
	// fmt.Println("version 2 updates")
	// fmt.Println(math.NaN() == math.NaN())
	fmt.Println("version 3, testing special function")
	fmt.Println(math.IsNan(math.Nan()))
}

// output:
// 1.2100000000000002

// version 2 output:
// # command-line-arguments
// ./puzz-7-num-lie.go:11:14: undefined: math
// ./puzz-7-num-lie.go:13:14: undefined: math

// version 2 output after importing math:
// # command-line-arguments
// ./puzz-7-num-lie.go:14:33: undefined: math.IsNan

// version 3 output after trying various things:
// # command-line-arguments
// ./puzz-7-num-lie.go:14:19: undefined: math.IsNan
// ./puzz-7-num-lie.go:14:30: undefined: math.Nan
