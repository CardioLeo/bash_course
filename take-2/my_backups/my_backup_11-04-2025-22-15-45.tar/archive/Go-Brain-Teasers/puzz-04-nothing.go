package main

import (
	"fmt"
)

func main() {
	n := nil
	fmt.Println(n)
}

// output is as follows, next two lines:
// # command-line-arguments
// ./puzz-4-nothing.go:8:7: use of untyped nil in assignment

// yeah, this is in keeping with the puzzle, as it says
// that the code "will not compile" - rings true
