package main

import (
	"fmt"
)

func main() {
	msg := "//pi symbol// = 3.14159265358..."
	fmt.Printf("%T ", msg[0])
	for _, c := range msg {
		fmt.Printf("%T\n", c)
		break
	}
}

// output: uint8 int32

// roughly as expected
// actually, it's a bit surprising because I didn't use an actual Greek pi!
