package main

import (
	"fmt"
)

// Point is a 2D point

type Point struct {
	X int
	Y int
}

func main() {
	p := Point{1, 2}
	fmt.Printf("%v\n", p) // {1 2}
}

// this is the code on the second page of the puzzle
// and yeah, this outputs the same {1 2} output listed above
// as expected

// the point of the puzzle is that because the first version of the puzzle
// uses a type with no name, called "embedding"

// was going to add another comment, but have to go
