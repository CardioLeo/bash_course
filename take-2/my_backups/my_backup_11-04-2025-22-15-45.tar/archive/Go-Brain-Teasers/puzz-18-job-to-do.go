package main

import (
	"fmt"
)

type Job struct {
	State string
	done chan struct{}
}

func (j *Job) Wait() {
	<-j.done
}

func (j *Job) Done() {
	j.State = "done"
	close(j.done)
}

func main() {
	ch := make(chan Job)
	go func() {
		j := <-ch
		j.Done()
	}()
	job := Job{"ready", make(chan struct{})}
	ch <- job
	job.Wait()
	fmt.Println(job.State)
}

// got the following output:

// # command-line-arguments
// ./puzz-18-job-to-do.go:17:4: j.state undefined (type *Job has no field or method state, but does have field State)

// however, it is supposed to print "ready"
// I need to reread the code and look for my mistakes

// ah, in line 17 I forgot to capitalize the S in j.State
// now fixed

// now it prints "ready"
