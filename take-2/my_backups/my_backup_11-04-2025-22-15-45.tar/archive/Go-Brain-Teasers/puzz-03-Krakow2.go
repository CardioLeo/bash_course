package main

import (
	"fmt"
	"unicode/utf8"
)

func main() {
	city := "Krakow"
	// ha, I don't have easy the special character
	//which the puzzle requires... and I'm offline
	fmt.Println(utf8.RuneCountInString(city))
}

// this gives the same output as the first version, because
// the special character still isn't used
// nevertheless, it is helpful for me as a way of reviewing
// the GoLang puzzles and practicing typing out GoLang code
