package main

import (
	"encoding/json"
	"fmt"
	"log"
	"time"
)

func main() {
	t1 := time.Now()
	data, err := json.Marshal(t1)
	if err != nil {
		log.Fatal(err)
	}

	var t2 time.Time
	if err := json.Unmarshal(data, &t2); err != nil {
		log.Fatal(err)
	}
	fmt.Println(t1 == t2)
}

// initial output:
// # command-line-arguments
// ./puzz-9-just-time.go:18:5: err != json.Unmarshal(data, &t2) (untyped bool value) is not used
// however, this is not the correct output; so I'll be reviewing the golang code

// correct output:
// false
// on line 18, I had written "!=" instead of ":="
// and so I got the earlier error output; fixing it gave moreso the right output
