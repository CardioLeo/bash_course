package main

import (
	"fmt"
)

type OSError int

func (e *OSError) Error() string {
	return fmt.Sprintf("error #%d", *e)
}

func FileExists(path string) (bool, error) {
	var err error
	return false, err // TODO
}

func main() {
	if _, err := FileExists("/no/such/file"); err != nil {
		fmt.Printf("error: %s\n", err)
	} else {
		fmt.Println("OK")
	}
}

// change line 14 to var err error

// I made line 14 into var error *OSError

// doesn't compile; here is the output:
// # command-line-arguments
// ./puzz-19-to-err-or-not2.go:14:6: syntax error: unexpected name err at end of statement

// I made line 14 say "val err error"
// but got the same message about line 19 as before - syntax error
// I looked closely over the code both in the book and my doc, but
// it's unclear what the real problem is
// or if the point is about the error message?

// ha - read it all closely all over again
// the mistake was mine - a typo. I wrote "val" instead of "var"
// I did this in the main code and in the comments!
// fixed now - lets see how both versions run

// the code now compiles and runs and prints out "OK"
