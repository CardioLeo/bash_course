package main

import (
	"fmt"
	"time"
)

// they have a comment here saying, "Log is a log message"
// I mean, good to know

type Log struct {
	Message string
	time.Time
}

func main() {
	ts := time.Date(2009, 11, 10, 0, 0, 0, 0, time.UTC)
	log := Log{"Hello", ts}
	fmt.Printf("%v\n", log)
}

// initial output:
// 2009-11-10 00:00:00 +0000 UTC
// I think the expectation, why this is a puzzle, is that it didn't
// print any culy braces around the output
