package main

import (
	"fmt"
	"strconv"
)

func main() {
	i := 169
	s := strconv.Itoa(i)
	fmt.Println(s)
	fmt.Println(i) // this was a line I added just to see...
}

// prints the same output - but presumably a call 
// to tell their type would say s was a string and i was an int
