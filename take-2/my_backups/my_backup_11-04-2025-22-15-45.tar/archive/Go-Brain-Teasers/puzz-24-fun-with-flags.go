package main

import (
	"fmt"
)

type Flag int

func main() {
	var i interface{} = 3
	f := i.(Flag)
	fmt.Println(f)
}

// I'm not going to reproduce the output right now
// but it is expected - it panics
