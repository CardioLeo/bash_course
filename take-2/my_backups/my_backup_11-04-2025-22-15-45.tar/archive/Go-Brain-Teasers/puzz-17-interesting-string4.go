package main

import (
	"fmt"
)

func main() {
	m := map[string]int{
		"hello": 3,
	}
	key := []byte{'h', 'e', 'l', 'l', 'o'}
	val := m[string(key)] // no memory allocation // <- this is a comment in the book's code
	fmt.Println(val) // 3 // <- also a comment from the book
}

// yeah, this code prints out 3

// I need to study more just what the code in this one does

// I only kind of understand it
// in particular, I don't understand what line 12 does - what is it and
// why doesn't it allocate memory?
