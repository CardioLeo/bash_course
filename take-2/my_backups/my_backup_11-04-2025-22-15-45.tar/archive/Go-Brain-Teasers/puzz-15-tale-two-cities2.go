package main

import (
	"fmt"

	"golang.org/x/text/unicode/norm"
)

func main() {
	city1, city2 := "Krakow", "Krako`w"
	city1, city2 = norm.NFC.String(city1), norm.NFC.String(city2)
	fmt.Println(city1 == city2)
}

// unsurprisingly, running this code yielded the following error:

// puzz-15-tale-two-cities2.go:6:2: no required module provides package golang.org/x/text/unicode/norm: go.mod file not found in current directory or any parent directory; see 'go help modules'

// which, frankly, I wondered if that might happen.
