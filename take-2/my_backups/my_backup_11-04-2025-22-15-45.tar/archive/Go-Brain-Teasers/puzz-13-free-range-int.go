package main

import (
	"fmt"
)

func fibs(n int) chan int {
	ch := make(chan int)

	go func() {
		a, b := 1, 1
		for i := 0; i < n; i++ {
			ch <- a
			a, b = b, a+b
		}
	}()

	return ch
}

func main() {
	for i := range fibs(5) {
		fmt.Printf("%d ", i)
	}
	fmt.Println()
}

// gave error messages:
// 1 1 2 3 5 fatal error: all goroutines are asleep - deadlock!
// goroutine 1 [chan receive]:
// main.main()
// [...]/puzz-13-free-range-int.go:22 +0x94
// exit status 2

// this is what the book predicted would occur - deadlock

// the problem with this code, it says, is that the channel
// doesn't get closed


