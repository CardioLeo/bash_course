package main

import (
	"fmt"
)

func main() {
	fmt.Println("first example")
	s := `a/tb`
	fmt.Println(s)
	fmt.Println("second example")
	fmt.Println("\u2122") // will print TM symbol
	fmt.Println("third example")
	request := `GET / HTTP/1.1
Host: www.353solutions.com
Connection: Close
	`
	fmt.Println(request)
}

// prints out quite literally, "a/tb"

// the backtics area way to make or denote "raw strings," or
// "multiline strings." This is Puzzle 5, version 2.

// double quotation marks make for "interpreted strings," which are
// more flexible because more abstract than raw strings created
// merely with backtics
