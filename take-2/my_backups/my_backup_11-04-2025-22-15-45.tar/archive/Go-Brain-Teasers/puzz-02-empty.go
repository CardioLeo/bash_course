package main

import (
	"fmt"
)

func main() {
	var m map[string]int
	fmt.Println(m["errors"])
}

// yeah, this runs and results in a zero, as the book says
