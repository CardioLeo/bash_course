package main
import (
	"fmt"
)

func main() {
	var pi = 355 / 113.0
	fmt.Println(pi)
}

// by contrast with pi.go, which divides 22 / 7.0, this division of constants
// does actually print exactly what the brain teasers book gives us
// it gave: 3.1415929203539825
// - versus: 3.142857142857143
