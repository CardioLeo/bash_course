package main

import (
	"fmt"
)

func main() {
	ch := make(chan int, 2)
	ch <- 1
	ch <- 2
	ch <- 3 // this is supposed to make it deadlock, according to the book - lets see
	<- ch
	close(ch)
	a := <-ch
	b := <-ch
	fmt.Println(a, b)
}

// yes, this deadlocked
// here is the error it gave me

// fatal error: all goroutines are asleep - deadlock!

// goroutine 1 [chan send]:
// main.main()
//	/home/echocslsk/Documents/Coding/Languages/GoLang/Go-Brain-Teasers/my-ver-code/puzz-16-what-in-channel2.go:11 +0x58
// exit status 2
