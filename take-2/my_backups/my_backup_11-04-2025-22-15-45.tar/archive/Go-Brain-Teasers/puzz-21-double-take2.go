package main

import (
	"fmt"
)

func init() {
	fmt.Printf("A ")
}

func init() {
	fmt.Printf("B \n")
}

		// note: the A and B look italized in the book

func main() {
}

// code prints "A B " as expected from reading the book previously
// 
// I want to test this without the command in main

// wow, it still runs, even with nothing in main
// it even prints out exactly the same so long as I add the "\n" to the
// second init()
