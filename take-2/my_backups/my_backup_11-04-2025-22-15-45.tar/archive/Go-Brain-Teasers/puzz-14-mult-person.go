package main

import (
	"fmt"
)

func main() {
	a, b := 1, 2
	b, c := 3, 4
	fmt.Println(a, b, c)
}

// it outputs: 1 3 4
// which makes sense, since b is redefined in the second line of main

// curiously, it sounds like it only works with new varialbes on
// the left side of the second initailization statement.
// It reads:
// "If you have no new variables, you'll get a compilation error."

// actually, though, this seems dangerous...... I'd rather the
// compilation error still remained, because it would be safer.
