package main

import (
	"fmt"
	"sync"
)

func main() {
	var count int
	var wg sync.WaitGroup

	for i := 0; i < 1_000_000; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			count++
		}()
	}
	wg.Wait()
	fmt.Println(count)
}

// the book says, "This code will print: 891239"
// but then has a box saying, "Your output might be different, but it will be below 1,000,000."

// command to look at assembly output of the program:
// go tool compile -S count.go

// however, interestingly, the above command goes like such:

// $ go tool compile -S count.go
// open count.go: no such file or directory

// So I tried running it regarding the name of the current file and
// got even more puzzling responses - especially since it runs fine 
// normally

// $ go tool compile -S puzz-23-count-million.go 
// puzz-23-count-million.go:4:2: could not import fmt (file not found)
// puzz-23-count-million.go:5:2: could not import sync (file not found)

// next I tried the next suggestion; running this command:
// $ go run -race puzz-23-count-million.go
// and got the following output:

/*
==================
WARNING: DATA RACE
Read at 0x00c00012e078 by goroutine 7:
  main.main.func1()
      /home/echocslsk/Documents/Coding/Languages/GoLang/Go-Brain-Teasers/my-ver-code/puzz-23-count-million.go:16 +0x84

Previous write at 0x00c00012e078 by goroutine 8:
  main.main.func1()
      /home/echocslsk/Documents/Coding/Languages/GoLang/Go-Brain-Teasers/my-ver-code/puzz-23-count-million.go:16 +0x96

Goroutine 7 (running) created at:
  main.main()
      /home/echocslsk/Documents/Coding/Languages/GoLang/Go-Brain-Teasers/my-ver-code/puzz-23-count-million.go:14 +0x78

Goroutine 8 (finished) created at:
  main.main()
      /home/echocslsk/Documents/Coding/Languages/GoLang/Go-Brain-Teasers/my-ver-code/puzz-23-count-million.go:14 +0x78
==================
==================
WARNING: DATA RACE
Write at 0x00c00012e078 by goroutine 54:
  main.main.func1()
      /home/echocslsk/Documents/Coding/Languages/GoLang/Go-Brain-Teasers/my-ver-code/puzz-23-count-million.go:16 +0x96

Previous write at 0x00c00012e078 by goroutine 57:
  main.main.func1()
      /home/echocslsk/Documents/Coding/Languages/GoLang/Go-Brain-Teasers/my-ver-code/puzz-23-count-million.go:16 +0x96

Goroutine 54 (running) created at:
  main.main()
      /home/echocslsk/Documents/Coding/Languages/GoLang/Go-Brain-Teasers/my-ver-code/puzz-23-count-million.go:14 +0x78

Goroutine 57 (finished) created at:
  main.main()
      /home/echocslsk/Documents/Coding/Languages/GoLang/Go-Brain-Teasers/my-ver-code/puzz-23-count-million.go:14 +0x78
==================
831159
Found 2 data race(s)
exit status 66
*/
