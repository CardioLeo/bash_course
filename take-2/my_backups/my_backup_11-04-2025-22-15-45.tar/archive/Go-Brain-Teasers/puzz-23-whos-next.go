package main

import (
	"fmt"
)

var (
	id = nextID()
)

func nextID() int {
	id++
	return id
}

func main() {
	fmt.Println(id)
}

// as the book says; it won't compile
// this was what I was expecting from C++
// since id is never really initialized

// it appears that this means that golang uses hoisting, though,
// like in JavaScript - which you can't do in C++, to my knowledge

// $ go run puzz-24-whos-next.go 
// # command-line-arguments
// ./puzz-24-whos-next.go:8:2: initialization cycle for id
// 	./puzz-24-whos-next.go:8:2: id refers to
//	./puzz-24-whos-next.go:11:6: nextID refers to
//	./puzz-24-whos-next.go:8:2: id
