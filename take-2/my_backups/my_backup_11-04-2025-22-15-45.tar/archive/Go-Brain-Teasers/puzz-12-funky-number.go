package main

import (
	"fmt"
)

func main() {
	fmt.Println(0x1p-2)
}

// This printed out what the book says it would: "0.25"
// however, it took what felt like forever - maybe even 30 seconds
// to print it out... which didn't seem right.
// Anyways. I figured it was octal- but wasn't expecting
// exactly that output.
