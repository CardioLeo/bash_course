package helpers

type SomeType struct {
	TypeName string
	TypeNumber int
}
